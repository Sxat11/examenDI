﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ExamenDI
{
    public partial class ValidateTextBox : UserControl
    {
        public ValidateTextBox()
        {
            InitializeComponent();
            this.Height = textBox1.Height + 20;
            textBox1.Width = this.Width - 20;
        }

        public enum Tipo
        {
            Numérico,
            Textual
        }
        private Tipo texto;
        [Category("Texto")]
        [Description("Define el texto del ValidateTextBox")]
        public Tipo Texto
        {
            get
            {
                //this.Refresh();
                return texto;
            }
            set { texto = value; }
        }


        [Category("Texto")]
        [Description("Define si el ValidateTextBox es multilinea o no")]
        public bool Multilinea
        {
            get { return textBox1.Multiline; }
            set { textBox1.Multiline = value; }
        }

        [Category("Texto")]
        [Description("Texto del TxtBox")]
        public string Text
        {
            get
            {
                return textBox1.Text;
                // set { t}
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            Pen lapizVerde = new Pen(Color.Green, 5);
            Pen lapizRojo = new Pen(Color.Red, 5);
            //Rectangle rectangulo = new Rectangle(5, 5, this.Width - 5, this.Height - 5);
            Rectangle rectangulo = new Rectangle(5, 5, this.Width - 10, textBox1.Height + 10);


            if (comprobar())
            {
                g.DrawRectangle(lapizVerde, rectangulo);

            }
            else
            {
                g.DrawRectangle(lapizRojo, rectangulo);
            }

        }

        private bool comprobar()
        {
            bool respuesta = true;
            if (Texto == Tipo.Numérico)
            {
                foreach (char c in textBox1.Text)
                {
                    if (!char.IsDigit(c))
                    {
                        respuesta = false;
                    }
                }

            }
            else
            {
                foreach (char c in textBox1.Text)
                {
                    if (char.IsDigit(c))
                    {
                        respuesta = false;
                    }
                }

            }
            return respuesta;
        }
        private void CambiaTexto(object sender, EventArgs e)
        {
            comprobar();
            this.Refresh();
        }

        private void ValidateTextBox_Resize(object sender, EventArgs e)
        {
            textBox1.Width = this.Width - 20;
            this.Height = textBox1.Height + 20;

        }

        private void ValidateTextBox_Load(object sender, EventArgs e)
        {

        }
    }
}
