﻿namespace PruebasExamenDI
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.generoBox = new System.Windows.Forms.GroupBox();
            this.mujerS = new System.Windows.Forms.RadioButton();
            this.HombreS = new System.Windows.Forms.RadioButton();
            this.txtBoxImg = new System.Windows.Forms.TextBox();
            this.fotolbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnImg = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.lblFriki = new System.Windows.Forms.Label();
            this.EdadTextBox2 = new ExamenDI.ValidateTextBox();
            this.txtNombre = new ExamenDI.ValidateTextBox();
            this.generoBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(163, 201);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(160, 24);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // generoBox
            // 
            this.generoBox.Controls.Add(this.mujerS);
            this.generoBox.Controls.Add(this.HombreS);
            this.generoBox.Location = new System.Drawing.Point(55, 252);
            this.generoBox.Margin = new System.Windows.Forms.Padding(4);
            this.generoBox.Name = "generoBox";
            this.generoBox.Padding = new System.Windows.Forms.Padding(4);
            this.generoBox.Size = new System.Drawing.Size(215, 66);
            this.generoBox.TabIndex = 3;
            this.generoBox.TabStop = false;
            this.generoBox.Text = "Sexo";
            this.generoBox.Enter += new System.EventHandler(this.generoBox_Enter);
            // 
            // mujerS
            // 
            this.mujerS.AutoSize = true;
            this.mujerS.Location = new System.Drawing.Point(113, 25);
            this.mujerS.Margin = new System.Windows.Forms.Padding(4);
            this.mujerS.Name = "mujerS";
            this.mujerS.Size = new System.Drawing.Size(61, 20);
            this.mujerS.TabIndex = 1;
            this.mujerS.TabStop = true;
            this.mujerS.Text = "Mujer";
            this.mujerS.UseVisualStyleBackColor = true;
            // 
            // HombreS
            // 
            this.HombreS.AutoSize = true;
            this.HombreS.Location = new System.Drawing.Point(9, 25);
            this.HombreS.Margin = new System.Windows.Forms.Padding(4);
            this.HombreS.Name = "HombreS";
            this.HombreS.Size = new System.Drawing.Size(77, 20);
            this.HombreS.TabIndex = 0;
            this.HombreS.TabStop = true;
            this.HombreS.Text = "Hombre";
            this.HombreS.UseVisualStyleBackColor = true;
            this.HombreS.CheckedChanged += new System.EventHandler(this.HombreS_CheckedChanged);
            // 
            // txtBoxImg
            // 
            this.txtBoxImg.Location = new System.Drawing.Point(123, 337);
            this.txtBoxImg.Margin = new System.Windows.Forms.Padding(4);
            this.txtBoxImg.Name = "txtBoxImg";
            this.txtBoxImg.Size = new System.Drawing.Size(145, 22);
            this.txtBoxImg.TabIndex = 5;
            this.txtBoxImg.Text = "img";
            // 
            // fotolbl
            // 
            this.fotolbl.AutoSize = true;
            this.fotolbl.Location = new System.Drawing.Point(59, 341);
            this.fotolbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.fotolbl.Name = "fotolbl";
            this.fotolbl.Size = new System.Drawing.Size(37, 16);
            this.fotolbl.TabIndex = 6;
            this.fotolbl.Text = "Foto:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 91);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "Nombre:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 150);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "Edad:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 204);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Aficiones:";
            // 
            // btnImg
            // 
            this.btnImg.Location = new System.Drawing.Point(283, 337);
            this.btnImg.Margin = new System.Windows.Forms.Padding(4);
            this.btnImg.Name = "btnImg";
            this.btnImg.Size = new System.Drawing.Size(41, 28);
            this.btnImg.TabIndex = 10;
            this.btnImg.UseVisualStyleBackColor = true;
            this.btnImg.Click += new System.EventHandler(this.btnImg_Click);
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(77, 393);
            this.btnAceptar.Margin = new System.Windows.Forms.Padding(4);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(117, 28);
            this.btnAceptar.TabIndex = 11;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(203, 393);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(121, 28);
            this.btnCancelar.TabIndex = 12;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // lblFriki
            // 
            this.lblFriki.AutoSize = true;
            this.lblFriki.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFriki.Location = new System.Drawing.Point(129, 11);
            this.lblFriki.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFriki.Name = "lblFriki";
            this.lblFriki.Size = new System.Drawing.Size(119, 46);
            this.lblFriki.TabIndex = 13;
            this.lblFriki.Text = "FRIKI";
            this.lblFriki.Click += new System.EventHandler(this.lblFriki_Click);
            // 
            // EdadTextBox2
            // 
            this.EdadTextBox2.Location = new System.Drawing.Point(163, 133);
            this.EdadTextBox2.Margin = new System.Windows.Forms.Padding(5);
            this.EdadTextBox2.Multilinea = false;
            this.EdadTextBox2.Name = "EdadTextBox2";
            this.EdadTextBox2.Size = new System.Drawing.Size(169, 42);
            this.EdadTextBox2.TabIndex = 1;
            this.EdadTextBox2.Texto = ExamenDI.ValidateTextBox.Tipo.Numérico;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(163, 76);
            this.txtNombre.Margin = new System.Windows.Forms.Padding(5);
            this.txtNombre.Multilinea = false;
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(169, 42);
            this.txtNombre.TabIndex = 0;
            this.txtNombre.Texto = ExamenDI.ValidateTextBox.Tipo.Textual;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 436);
            this.Controls.Add(this.lblFriki);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.btnImg);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fotolbl);
            this.Controls.Add(this.txtBoxImg);
            this.Controls.Add(this.generoBox);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.EdadTextBox2);
            this.Controls.Add(this.txtNombre);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form2";
            this.Text = "Introduccion de datos";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.generoBox.ResumeLayout(false);
            this.generoBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ExamenDI.ValidateTextBox txtNombre;
        private ExamenDI.ValidateTextBox EdadTextBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox generoBox;
        private System.Windows.Forms.RadioButton mujerS;
        private System.Windows.Forms.RadioButton HombreS;
        private System.Windows.Forms.TextBox txtBoxImg;
        private System.Windows.Forms.Label fotolbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnImg;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Label lblFriki;
    }
}