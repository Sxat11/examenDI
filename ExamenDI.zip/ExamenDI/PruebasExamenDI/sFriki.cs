﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebasExamenDI
{
    internal class sFriki
    {
        //        Se dispone de una estructura(u objeto si lo prefieres) denominada sFriki con los siguientes campos:
        //– Nombre(Cadena) : Guardará tanto nombre como apellidos
        //– Edad(integer)
        //– Afición principal: Será un enumerado(denominado eAficion) con posibles valores: Manga, SciFi, RPG, 
        //            Fantasia, Terror, Tecnologia.
        //– Sexo: Enumerado Hombre, Mujer (denominado eSexo)
        //– Sexo opuesto: También el enumerado eSexo.Indicará el sexo con el que desea buscar una relación
        //matrimonial.
        //– Foto: Cadena que indica la posición de la foto (se te entregarán varias imágenes que puedes utilizar).

        private string nombre;
        private int edad;
        private eAficion aficion;
        private eSexo sexo;
        public string foto;

        public enum eAficion
        {
            Manga,
            SciFi,
            RGP,
            Fantasia,
            Terror,
            Tecnología
        }
        public enum eSexo
        {
            Hombre,
            Mujer
        }
        public sFriki()
        {

        }
        public sFriki(string nombre, int edad, eAficion aficion, eSexo sexo, string foto)
        {
            this.nombre = nombre;
            this.foto = foto;
            this.edad = edad;
            this.aficion = aficion;
            this.sexo = sexo;

        }
        public override string ToString()
        {
            return nombre;
        }


    }
}
