﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PruebasExamenDI
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public string Nombre;
        public string Edad;
        public string Aficion;
        public string Genero;
        public string Foto;

        private void lblFriki_Click(object sender, EventArgs e)
        {

        }



        private void btnImg_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Filter = " JPG |*.jpg |Todos los archivos |*.*";
                //dialog.InitialDirectory 
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    txtBoxImg.Text = dialog.FileName;
                   
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            HombreS.Checked = true;

            string[] aficiones = { "Manga",
            "SciFi",
            "RGP",
            "Fantasia",
            "Terror",
            "Tecnología" };
            foreach (string f in aficiones)
            {
                comboBox1.Items.Add(f);
            }
            comboBox1.SelectedIndex = 2;

        }
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Nombre = txtNombre.Text;
            Edad = EdadTextBox2.Text;
            Aficion = comboBox1.Text;
            Genero = generoBox.Text;
            Foto = txtBoxImg.Text;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            //  this.Close();
        }

        private void generoBox_Enter(object sender, EventArgs e)
        {

        }

        private void HombreS_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
