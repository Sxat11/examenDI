﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PruebasExamenDI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private List<sFriki> frikis = new List<sFriki>();
        private void Form1_Load(object sender, EventArgs e)
        {
            //frikis.Add(new sFriki("Manuel", 20, sFriki.eAficion.RGP, sFriki.eSexo.Hombre, "foto"));
            //frikis.Add(new sFriki("Samuel", 20, sFriki.eAficion.RGP, sFriki.eSexo.Hombre, "foto"));
            //frikis.Add(new sFriki("Gabriel", 20, sFriki.eAficion.RGP, sFriki.eSexo.Hombre, "foto"));

            //if (frikis.Count > 0)
            //{
            //    actualizarLista();
            //}
            timer1.Start();
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            int ind = 0;
            for (int i = listBox1.SelectedIndices.Count - 1; i >= 0; i--) //IMPORTANTE
            {
                ind = listBox1.SelectedIndices[i];
                listBox1.Items.RemoveAt(ind);
                frikis.RemoveAt(ind);
            }
            if (frikis.Count == 0)
            {
                imgFoto.Image = null;
            }
            else
            {
                Image imagen = Image.FromFile(frikis[ind].foto);
                imgFoto.Image = imagen;
            }
            // actualizarLista();
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            //form2.ShowDialog();

            //    if (form2.ShowDialog() == DialogResult.OK)
            //    {
            //        int edadt;
            //        int.TryParse(form2.Edad, out int result);
            //        {
            //            edadt = result;
            //        }
            //        sFriki.eAficion aficion = (sFriki.eAficion)Enum.Parse(typeof(sFriki.eAficion), form2.Aficion);
            //        sFriki.eSexo sexo = (sFriki.eSexo)Enum.Parse(typeof(sFriki.eSexo), form2.Genero.Trim(), true);
            //        sFriki.eSexo sexoOP = (sFriki.eSexo)Enum.Parse(typeof(sFriki.eSexo), form2.SexoOp.Trim(), true);

            //        listBox1.Items.Clear();
            //        frikis.Add(new sFriki(form2.Nombre, edadt, aficion, sexoOP, sexoOP, form2.Foto));
            //        actualizarLista();
            //    }
            //}
            if (form2.ShowDialog() == DialogResult.OK)
            {
                // 1. Simplificar conversión de edad
                int.TryParse(form2.Edad, out int edadt);

                // 2. Usar TryParse para evitar excepciones de ArgumentException
                // Intentamos convertir Aficion, si falla usamos la primera del Enum
                if (!Enum.TryParse(form2.Aficion, true, out sFriki.eAficion aficion))
                    aficion = sFriki.eAficion.RGP;

                // Intentamos convertir Genero
                if (!Enum.TryParse(form2.Genero, true, out sFriki.eSexo sexo))
                    sexo = sFriki.eSexo.Hombre;

                // Intentamos convertir SexoOp
                if (!Enum.TryParse(form2.SexoOp, true, out sFriki.eSexo sexoOP))
                    sexoOP = sFriki.eSexo.Mujer;

                // 3. Añadir a la lista y actualizar
                // Nota: Revisa que el constructor de sFriki reciba los parámetros en este orden
                frikis.Add(new sFriki(form2.Nombre, edadt, aficion, sexo, sexoOP, form2.Foto));
                listBox1.Items.Clear();
                actualizarLista();
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                if (listBox1.Items.Count > 0)
                {
                    int ind = 0;
                    ind = listBox1.SelectedIndex;
                    Image imagen = Image.FromFile(frikis[ind].foto);
                    imgFoto.Image = imagen;
                }
            }
            catch (Exception ex)
            {
                // MessageBox.Show("Has cogido un indice raro");
            }
        }

        private void actualizarLista()
        {

            //if (listBox1.Items.Count > 0)
            //{
            for (int i = 0; i < frikis.Count; i++)
            {
                listBox1.Items.Add(frikis[i].ToString());
            }

            //  }
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        string titulo = "FrikiLove Inc.";
        int i = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (titulo.Length - 1 < i)
            {
                i = 0;
                this.Text = "";
            }
            this.Text += titulo[i];
            i++;
        }
    }
}
